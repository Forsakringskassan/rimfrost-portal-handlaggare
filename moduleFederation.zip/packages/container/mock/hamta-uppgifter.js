export default {
  defaultResponse: {
    status: 200,
    body: [{ uid: 1234, url: "http://localhost:8081/uppgift01.js" }],
  },
};
