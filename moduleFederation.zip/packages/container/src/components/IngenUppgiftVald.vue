<script setup lang="ts"></script>

<template>
  <div class="container">
    <h1>Inget ärende valt</h1>
    <p>Välj ett ärende i menyn till vänster</p>
  </div>
</template>

<style scoped>
.container {
  padding: 0.75rem;
}
</style>
