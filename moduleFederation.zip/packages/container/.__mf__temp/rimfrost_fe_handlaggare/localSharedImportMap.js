
// Windows temporarily needs this file, https://github.com/module-federation/vite/issues/68

    import {loadShare} from "@module-federation/runtime";
    const importMap = {
      
    }
      const usedShared = {
      
    }
      const usedRemotes = [
      ]
      export {
        usedShared,
        usedRemotes
      }
      